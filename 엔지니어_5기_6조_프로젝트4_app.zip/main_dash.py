from dash import Dash, html
import pandas as pd
import dash_bootstrap_components as dbc

from util.google import url_to_dataframe

from components.layoutSecondTab import make_layout_second_tab

from pages.eventEffectTab1 import make_page_event_tab1
from pages.eventEffectTab2 import make_page_event_tab2
from pages.eventSales import make_page_event_sale

from pages.modelCustomerClassification import make_page_model_customer_classification
from pages.modelKeyword import make_page_model_keyword

from pages.multiSelect import make_page_multi_select
from pages.newCustomer import make_page_new_customer
from pages.repurchase import make_page_repurchase
from pages.sampleGraph import sample

processed_df_link = "https://drive.google.com/file/d/1l9S5UU5f7L-OeKWhMRctCdSvVVxlFt_8/view?usp=sharing"

df = url_to_dataframe(processed_df_link)
df['구매일'] = pd.to_datetime(df['구매일'])

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css', dbc.themes.QUARTZ]

app = Dash(__name__, external_stylesheets=external_stylesheets, assets_folder='./assets')

############################
layout_first_tab = []
layout_first_tab.extend(sample(df.copy()))
layout_first_tab.extend(make_page_multi_select(df.copy()))

layout_repurchase = [
    make_page_event_sale(df.copy()),
    make_page_event_tab1(),
    make_page_event_tab2(),
    make_page_repurchase(df.copy()),
    make_page_new_customer(df.copy())
]

layout_second_tab = make_layout_second_tab(layout_repurchase)

layout_third_tab = []
layout_third_tab.extend(make_page_model_keyword())
layout_third_tab.extend(make_page_model_customer_classification())

tabs = dbc.Tabs([
        dbc.Tab(label='유아용품 쇼핑몰 A사 현황', children=layout_first_tab),
        dbc.Tab(label='데이터분석', children=[layout_second_tab]), 
        dbc.Tab(label='모델링', children=layout_third_tab),
    ])

app.layout = html.Div(
    [tabs],
    className="body__sheet"
)

if __name__ == '__main__':
    app.run_server(debug=True)

