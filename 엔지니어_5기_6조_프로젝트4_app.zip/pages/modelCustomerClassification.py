from dash import Dash, html, dcc, callback, Output, Input
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import plotly.graph_objects as go

def make_page_model_customer_classification():
  div_upper = html.Div(
      children=[
            html.Div(
                children=[
                    html.H1("고객 분류 모델"),
                    html.H2("분류 모델 RandomForest 사용")         
                ],
                style={'width': '50%', 'height': '100%'}
            ),
          ], 
        style={'display': 'flex'},
        className="row"
      )
  div_bottom = html.Div(
            children=[html.Img(src='assets/고객_분류_모델.webp', className="model__picture")],
            className="container--gradient row",
        )
  return [html.Div([
        div_upper,  
        div_bottom 
    ])]

