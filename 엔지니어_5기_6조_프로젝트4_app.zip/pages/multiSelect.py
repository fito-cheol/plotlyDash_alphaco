from dash import Dash, html, dcc, callback, Output, Input
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import plotly.graph_objects as go
import numpy as np
import dash_bootstrap_components as dbc


def make_fig(df):
  pass
def make_page_multi_select(df):
  # 1. select 1번 x축 선택 범주형 + 연속형
  # 2. select 2번 y축 선택 연속형
  # 3. 그래프 보여주는 곳
  # 4. might 그래프 타입
  # 5. might color 선택
  
  df = df.drop(columns=["Unnamed: 0", '상품명', '구매일(월)', '고객번호', 'ID'])
  df['구매연월'] = df['구매일'].dt.strftime("%Y%m")
  
  # 연속형 선택
  num_columns = df.select_dtypes(include=np.number).columns.tolist()
  # 범주형
  cat_columns = df.select_dtypes(exclude=np.number).columns.tolist()
  all_columns = cat_columns + num_columns
  math_method = ['합', '평균', '갯수']
  
  layout = [
        dbc.Card(
            children=[
                html.H1(children="직접 그래프 만들기"),
                html.Div(
                    children=[
                        html.Div(
                            children=[
                                html.Div(children='x축 선택', className="filter--text"),
                                dcc.Dropdown(all_columns, all_columns[0], id='dropdown-x', className='dropdown'),
                            ],
                            className="container",
                        ),
                        html.Div(
                            children=[
                                html.Div(children='y축 선택', className="filter--text"),
                                dcc.Dropdown(num_columns, num_columns[0], id='dropdown-y', className='dropdown'),
                            ],
                            className="container"
                        ),
                        html.Div(
                            children=[
                                html.Div(children='계산방법 선택', className="filter--text"),
                                dcc.Dropdown(math_method, math_method[0], id='dropdown-math', className='dropdown'),
                            ],
                            className="container"
                        ),
                    ], 
                    className="container"
                ),
                
                dcc.Loading(
                    id="loading-1",
                    type="default",
                    children=html.Div(id="loading-output-1")
                ),
            ],
            className="container--gradient"
        )
    ]

  @callback(
      Output("loading-output-1", "children"),
      Input('dropdown-x', 'value'),
      Input('dropdown-y', 'value'),
      Input('dropdown-math', 'value')
  )
  def update_graph(x_col, y_col, math_method):
    if not x_col or not y_col or (x_col == y_col):
        return [html.H1(children="그래프를 그릴 수 없습니다", style={ 'margin':"20px"})]
    
    if math_method == '합':
        dff = df[[x_col, y_col]].groupby(x_col).sum()
    elif math_method == '평균':
        dff = df[[x_col, y_col]].groupby(x_col).mean()
    elif math_method == '갯수':
        dff = df[[x_col, y_col]].groupby(x_col).count()
    
    if x_col in cat_columns:
        fig = px.bar(dff, x=dff.index, y=y_col, color= dff.index, color_discrete_sequence= px.colors.sequential.Plasma_r)
    else:
        fig = px.bar(dff, x=dff.index, y=y_col)
        
    layout = go.Layout(
        paper_bgcolor='rgba(255,255,255,0.7)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    fig.update_layout(layout)
    fig.update_layout(showlegend=False) 
    
    return [dcc.Graph(id='multi-graph', className="graph", figure=fig)]
      
    
  
  
  return layout




