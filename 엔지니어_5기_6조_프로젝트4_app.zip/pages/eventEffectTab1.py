from dash import Dash, html, dcc, callback, Output, Input
import plotly.graph_objects as go
import pandas as pd
import plotly.graph_objects as go

colors = ['#FF9933',] * 5
colors[0] = '#56BDF4'
colors2 = ['#56BDF4', '#D3D3D3']

def make_page_event_tab1():
    fig = go.Figure(data=[go.Bar(x=['이벤트제품','이벤트X제품'],
                                    y=[112.37, 59.43],
                                    marker_color=colors # marker color can be a single color value or an iterable
                                )])
    fig.update_layout(title_text='이벤트 유무에 따른 판매량')
    fig.update_xaxes(tickfont=dict(size=20))
    layout = go.Layout(
            paper_bgcolor='rgba(255,255,255,0.7)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
    fig.update_layout(layout)
    
    return dcc.Graph(figure=fig, className="graph")
