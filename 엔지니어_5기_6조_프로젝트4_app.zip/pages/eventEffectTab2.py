from dash import Dash, html, dcc, callback, Output, Input
import plotly.graph_objects as go
import pandas as pd
import plotly.graph_objects as go

colors = ['#FF9933',] * 5
colors[0] = '#56BDF4'
colors2 = ['#56BDF4', '#D3D3D3']

def make_page_event_tab2():

    fig = go.Figure(data=[go.Pie(labels = ['이벤트X제품도 구매', '이벤트제품만 구매'],
                            values = [12661, 1982])])
    fig.update_traces(hoverinfo='label+percent', textinfo='percent', textfont_size=20,textfont=dict(color='black'),
                marker=dict(colors=colors2, line=dict(color='#000000', width=2)))
    fig.update_layout(
            title={
                'text': "이벤트참여자가 이후 재구매한다면 구매제품",
                'y': 0.95,
                'x': 0.5,
                'xanchor': 'center',
                'yanchor': 'top'
            }
        )
    fig.update_layout(legend=dict( font=dict(size=20)))
    
    layout = go.Layout(
            paper_bgcolor='rgba(255,255,255,0.7)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
    fig.update_layout(layout)
    
    return dcc.Graph(figure=fig, className="graph")
      
