from dash import Dash, html, dcc, callback, Output, Input
import plotly.express as px
import dash_bootstrap_components as dbc
import plotly.graph_objects as go


def sample(df):
    layout = [
        dbc.Card(
            children=[
                html.H1(children='구매경로 별 매출', style={'textAlign':'center', 'color':'white'}),
                html.Div(children=[
                    dcc.Dropdown(df['유입경로'].unique(), '인스타그램', id='dropdown-selection', className='dropdown'),
                    dcc.Graph(id='graph-content', className="graph")        
                ], style={"width":"90%"})
            ],
            className="container--gradient"
        )
    ]


    @callback(
        Output('graph-content', 'figure'),
        Input('dropdown-selection', 'value')
    )
    def update_graph(value):
        
        dff = df[df['유입경로'] == value].groupby('구매일').sum()
        fig = px.line(dff, x=dff.index, y='구매금액')
        
        layout = go.Layout(
            paper_bgcolor='rgba(255,255,255,0.7)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        fig.update_layout(layout)
        return fig
    
    
    return layout

    
