import pandas as pd

def url_to_dataframe(url):
    file_id = url.split('/')[-2]
    download_url = 'https://drive.google.com/uc?id=' + file_id

    data = pd.read_csv(download_url, encoding='utf-8', low_memory=False)
    return data
