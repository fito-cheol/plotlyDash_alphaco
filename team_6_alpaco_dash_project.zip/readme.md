## 설치: pip install -r requirements.txt

## 패키지 저장: pip freeze > requirements.txt
