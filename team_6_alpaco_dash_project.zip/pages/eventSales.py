from dash import Dash, html, dcc, callback, Output, Input
import plotly.graph_objects as go
import pandas as pd
import plotly.graph_objects as go

def make_fig(df):
    df['구매일'] = pd.to_datetime(df['구매일'])
    df['구매일(월)'] = df['구매일'].dt.strftime("%Y%m")

    df_merge_event = df[(df['물품대분류'] == '체험팩') | 
                                    (df['상품명'].str.startswith('[1+1]')) | 
                                    (df['상품명'].str.startswith('(핫딜위크/1+1)')) | 
                                    (df['상품명'].str.startswith('(1+1)')) | 
                                    (df['상품명'].str.contains('쿠폰적용가')) | 
                                    (df['상품명'].str.contains('증정')) | 
                                    (df['상품명'].str.contains('체험팩'))]

    df_merge_event_new = df_merge_event.groupby('구매일(월)').count()
    df_merge_event_new


    fig = go.Figure(layout=go.Layout(title='이벤트제품 판매량'))
    fig.update_layout(
        title=dict(
            x=0.5,
            font=dict(size=24)
        )
    )

    fig.add_trace(go.Scatter(x= df_merge_event_new.index, 
                            y= df_merge_event_new["성별"],
                            name = '일반',
                            mode='lines+markers+text',
                            line={'color':'#1E90FF',
                                'width':6,
                                },
                            marker={'color':'#666699'},
                            showlegend=True))
    layout = go.Layout(
            paper_bgcolor='rgba(255,255,255,0.7)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
    fig.update_layout(layout)
    return fig
    
def make_page_event_sale(df):
    fig = make_fig(df)
    
    return [    
        dcc.Graph(
            id='graph_event_sale',
            figure=fig,
            className="graph"
        )
    ]


