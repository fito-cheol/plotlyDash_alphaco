from dash import Dash, html, dcc, callback, Output, Input
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import plotly.graph_objects as go


def make_page_model_keyword():
  div_upper = html.Div(
        children=[
            html.Div(
                children=[
                    html.H1("키워드 예측 모델"),
                    html.H3("시계열 예측 라이브러리인 Prophet을 사용") 
                ],
                style={'width': '50%', 'height': '100%'}
            ),
        ],
      style={'display': 'flex'},
      className="row"
    )
  div_bottom = html.Div(
    className="row container--gradient",
    children=[html.Img(src='assets/키워드모델.webp')])
  return [html.Div([
        div_upper,  
        div_bottom 
    ])]


