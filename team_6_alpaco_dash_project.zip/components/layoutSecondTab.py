from dash import Dash, html, dcc, callback, Output, Input
import dash_bootstrap_components as dbc

def make_layout_second_tab(pages):
    
    return html.Div(
            children=[
                html.Div(
                    children=[
                        html.Div(
                            children= pages[0],
                            className="container--gradient",
                            style={'width': '35%'}
                        ),
                        html.Div(
                            children=[
                                dbc.Tabs(
                                    children=[
                                        dbc.Tab(
                                            label='이벤트 효과 1',  # 탭 레이블 설정
                                            children= pages[1]
                                        ),
                                        dbc.Tab(
                                            label='이벤트 효과 2',  # 탭 레이블 설정
                                            children= pages[2]
                                        )
                                    ],
                                )
                            ],
                            className="container--gradient",
                            style={'width': '35%', "display":'block'}
                        ),
                        html.Div(
                            className="container--gradient",
                            children=[
                                html.H1(children="데이터 분석 결과"), 
                                html.H3(children="- 이벤트제품 구매자 수 증가 필요"), 
                                html.H3(children="- 신규 유입의 수 증가 필요"), 
                                html.H3(children="- 재구매 고객의 비율 증가 필요"), 
                                html.H1(children="개선안", style={'margin-top': '100px'}), 
                                html.H3(children="- 키워드 예측 모델"), 
                                html.H3(children="- 고객 분류 모델"), 
                            ],
                            style={'width': '30%', 'display':'block', 'color':'white'} 
                        ),
                    ],
                    style={'display': 'flex'}
                ),
                html.Div(
                    children=[
                        html.Div(
                            children= pages[3],
                            className="container--gradient",
                            style={'width': '50%', 'height': '100%'}  # 좌측 영역 스타일
                        ),
                        html.Div(
                            children= pages[4],
                            className="container--gradient",
                            style={'width': '50%', 'height': '100%'}  # 우측 영역 스타일
                        ),
                    ],
                    style={'display': 'flex'}  # 좌측과 우측 영역을 가로로 배치하기 위한 스타일
                ),
            ],
            style={'display': 'flex', 'flex-direction': 'column'}  # 전체 레이아웃을 세로로 배치하기 위한 스타일
        )

