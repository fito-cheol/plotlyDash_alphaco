from dash import dcc, html, callback, Output, Input

tabs_styles = {
    'height': '44px'
}
tab_style = {
    'borderBottom': '1px solid #d6d6d6',
    'padding': '6px',
    'fontWeight': 'bold'
}

tab_selected_style = {
    'borderTop': '1px solid #d6d6d6',
    'borderBottom': '1px solid #d6d6d6',
    'backgroundColor': '#119DFF',
    'color': 'white',
    'padding': '6px'
}


def make_tabs(layouts):
    
    # @callback(Output('tabs-content-inline', 'children'),
    #             Input('tabs-styled-with-inline', 'value'))
    # def change_tabs(tab):
        
    #     return layouts[tab]
            
    children = []
    for key, val in layouts.items():
        children.append(
            dcc.Tab(label=f'{key}', children=val )#, style=tab_style, selected_style=tab_selected_style) 
        )

    return dcc.Tabs(id="tabs-styled-with-inline", value='tab-1', children=[children], style=tabs_styles),

    
